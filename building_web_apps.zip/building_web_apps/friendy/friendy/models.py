from datetime import datetime
from hashlib import md5
from typing import Text

from flask_login import UserMixin
from sqlalchemy import desc
from sqlalchemy.orm import backref
from werkzeug.security import check_password_hash, generate_password_hash

from friendy import db


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(80))
    bio = db.Column(db.Text)
    posts = db.relationship('Post', backref='user', lazy="dynamic")

    def avatar(self, size):
        return 'http://www.gravatar.com/avatar/{}?d=mm&s={}'.format(md5(self.email.encode('utf-8')).hexdigest(), size)

    def save(self):
        db.session.add(self)
        db.session.commit()

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)


    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @staticmethod
    def get_by_email(email):
        return User.query.filter_by(email=email).first()

    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self.set_password(password)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text)
    last_modified = db.Column(db.DateTime)
    writer = db.Column(db.String(80))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    comments = db.relationship('Comment', backref="post", lazy="dynamic")

    @staticmethod
    def latest():
        return Post.query.order_by(desc(Post.last_modified)).all()

    def save(self):
        db.session.add(self)
        db.session.commit()

    def __init__(self, content, writer, user_id):
        self.content = content
        self.writer = writer
        self.last_modified = datetime.utcnow()
        self.user_id = user_id

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text)
    writer = db.Column(db.String(80))
    last_modified = db.Column(db.DateTime)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'))

    def save(self):
        db.session.add(self)
        db.session.commit()

    def __init__(self, content, writer, post_id):
        self.content = content
        self.writer = writer
        self.last_modified = datetime.utcnow()
        self.post_id = post_id


class Fake(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text)