import email
import profile
from csv import writer

from flask import flash, redirect, render_template, url_for
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy import databases

from . import app, db, lm
from .forms import AddPostForm, LoginForm, SignupForm, UserProfileForm
from .models import Post, User, Comment


@lm.user_loader
def load_user(user_id):
    return User.query.get(user_id)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/home', methods=["GET", "POST"])
def home():
    form = AddPostForm()
    posts = Post.latest()
    if form.validate_on_submit():
        new = Post(content=form.content.data, writer=current_user.username, user_id=current_user.id)
        new.save()
        flash("Posted")
        return redirect(url_for('home'))
    return render_template("home.html", form=form, posts=posts)

@app.route('/login', methods=["GET","POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.get_by_email(form.email.data)
        if user is not None and user.check_password(form.password.data):
            login_user(user, form.remember_me.data)
            flash("login successful")
            return redirect(url_for('home'))
        flash("Incorrect password or email")
    return render_template("login.html", form=form)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/signup', methods=["GET","POST"])
def signup():
    form = SignupForm()
    if form.validate_on_submit():
        new = User(username=form.username.data, email=form.email.data, password=form.password.data)
        new.save()
        flash("Registration was successful")
        return redirect(url_for('login'))
    return render_template("signup.html", form=form)

@app.route('/profile', methods=["GET","POST"])
@login_required
def profile():
    user = User.query.get(current_user.id)
    form = UserProfileForm()
    if form.validate_on_submit():
        user.email = form.email.data
        user.bio = form.bio.data
        user.save()
        flash("Changes were successful")
        return redirect(url_for('home'))
    form.email.data = user.email
    form.bio.data = user.bio
    return render_template('profile.html', form=form)

@app.route('/comment/<id>', methods=["GET", "POST"])
def comment(id):
    form = AddPostForm()
    if form.validate_on_submit():
        new = Comment(content=form.content.data, writer=current_user.username, post_id=id)
        new.save()
        flash('Comment added')
        return redirect(url_for('home'))
    return render_template("comment.html", form=form)